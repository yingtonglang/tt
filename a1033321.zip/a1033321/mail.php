<html>
  <head>
  </head>

  <body>
    <center><form action="" method="post">
      寄件人:<input type="text" name="sender"><br/>
      寄件信箱:<input type="text" name="sendmail"><br/>
      收件人:<input type="text" name="receive"><br/>
      內容:<input type="text" name="content"><br/>

      <input type="submit" value="送出資料">
      <input type="reset" value="清除資料">
    </form></center>
    
    <?php
      require("C:\AppServ\www\PHPMailer\PHPMailerAutoload.php");
      mb_internal_encoding('UTF-8');
      $mail=new PHPMailer();
      $mail->IsSMTP();
      $mail->SMTPAuth=true;

      $mail->Username="jpmqu26@gmail.com";
      $mail->Password="upcju406662";

      $mail->FromName = "jpmqu26";
      $webmaster_email = "jpmqu26@gmail.com";

      $email = "php@nuk.im";
      $name = "助教";
      $mail->From = $webmaster_email;

      $mail->AddAddress($email,$name);
      $mail->AddReplyTo($webmaster_email,"Squall.f");

      $mail->IsHTML(true);

      $mail->Subject="php 期末報到 A1033321";
      $mail->Body="A1033321 140.127.233.52 02-50-F2-8E-5B-E2";

      if($mail->Send()){
        echo "郵件寄出 已收到信<br/>";
      }
      else{
        echo "寄件發生錯誤：" . $mail->ErrorInfo."<br/>";
      }
    ?>
</body>
</html>
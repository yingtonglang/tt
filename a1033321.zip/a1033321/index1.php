<?php
  class PostOffice{
    function mailFiler(){
      $file = fopen("string.txt","r");
      while(!feof($file))
      {
        echo fgets($file). "<br />";
      }
      fclose($file);
    }

    function mailRegex(){
      $file = fopen("string.txt","r");
      while(!feof($file))
      {
      	if($cleaned = preg_replace("/[A-Za-z0-9 ]/", "", $search)){
          echo $cleaned;
        }
      }
      fclose($file);
    }

    function spiltroad(){
      $file = fopen("road.txt","r");
      for($i=0;!feof($file);$i++){ 
      echo mb_substr(fgets($file),6,4,"utf-8");
      echo "<br/>";
      }  

      echo $output[0];
      echo $output[1]; 
      echo $output[2];      
      echo $output[3];
      
      fclose($file);
    }

  }
?>
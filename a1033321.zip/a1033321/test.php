<meta charset="UTF-8">
<?php
  $file = fopen("road.txt","r");
    for($i=0;!feof($file);$i++){ 
      echo mb_substr(fgets($file),6,4,"utf-8");
      echo "<br/>";
    }  
     
    echo $output[0];
    echo $output[1]; 
    echo $output[2];      
    echo $output[3];
    fclose($file);
?>